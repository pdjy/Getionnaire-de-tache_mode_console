import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import java.util.Scanner;


public class main {

	/**
	 * @param args
	 */
	List<Membre> membres = new LinkedList<>();
	static ArrayList<Membre> aList = new ArrayList<>();
	
	// methode de recherche d'un membre
	public static Membre recherche(String NomMembre){
		Membre res = null;
		for(Membre m:aList){
			if(m.getNomMembre().equalsIgnoreCase(NomMembre)){
				res= m;
				break;
			}
		}
		return res; 
	}
	
	public static void editMembre(int index, String nom){
		Membre m3 = recherche(nom);
		if(m3 != null){
			System.out.println("Ce nom existe deja");
		}else{
			aList.set(index, new Membre(aList.size()+1, nom));
		}
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Scanner sc = new Scanner(System.in);
		String nom = "";
		int choix;
		
		do{
			//Menu();
			System.out.println("Faire votre choix: ");
			System.out.println("1 pour saisir le nom du membre");
			System.out.println("2 pour saisir le nom du membre a rechercher");
			
			choix = sc.nextInt();
			
			switch(choix){
			case 1: {
				System.out.println("Veuillez saisir le nom du membre: ");
				nom = sc.next();
				Membre m = new Membre(1, nom);
				aList.add(m);
				System.out.println(m.toString());
				System.out.println();
			}
			break;
			
			case 2: {
				System.out.println("Veuillez saisir le nom du membre a rechercher: ");
				nom = sc.next();
				Membre m2 = recherche(nom);
				if(m2 !=null){
					System.out.println(m2.toString());
					System.out.println();}
				else{
					System.out.println("Ce nom n'existe pas!");
					System.out.println();}
			}
			break;
			
			default:{
				System.out.println("Mauvais choix !");}
			}
		} while((choix == 1) || (choix == 2));
		
	}

}
