
public class assignation {
		
	Membre m=new Membre();
	Tache t=new Tache();
	public assignation(){
		
	}

//LA FONCTION DE CREATION D'UNE ASSIGNATION

	public static void addAssigner(assignation ass1) {

		assignation assigne1 = recherchAssignation(m.Id_Membre(), t.getId_tache());

		if (assigne1 != null) {
			System.out.println("Le nom saisi existe deja");

		} else {

			ListAssigne.add(ass1);
		}
	}

	private Object getId_tache() {
		// TODO Auto-generated method stub
		return null;
	}

	private Object Id_Membre() {
		// TODO Auto-generated method stub
		return null;
	}
}
